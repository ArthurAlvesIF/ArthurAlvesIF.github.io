package com.example.renan.sitards;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    static List<String> Titulo= new ArrayList<String>();
    static List<String> Descricao= new ArrayList<String>();
    static List<String> Imagem= new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (Titulo.size()==0) {
            Titulo.add("Evento de Informatica");
            Titulo.add("Testando");
            Descricao.add("csdks cc ceke ec ec ckekeç çcuç gaug ugekb vçKEBV EVEENEUNE CE");
            Descricao.add("Galerinha é só um teste para ajudar vocês");
            Imagem.add("https://www.aprenderexcel.com.br//imagens/post/385/2901-1.jpg");
            Imagem.add("https://www.aprenderexcel.com.br//imagens/post/385/2901-1.jpg");
        }

        ListView listView= findViewById(R.id.ListNoticias);
        CustomAdapter customAdapter = new CustomAdapter();
        listView.setAdapter(customAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(),NoticiaExpand.class);
                Bundle a = new Bundle();
                a.putString("Titulo",Titulo.get(i));
                a.putString("Descricao",Descricao.get(i));
                a.putString("foto",Imagem.get(i));
                intent.putExtras(a);
                startActivity(intent);
            }
        });


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),NoticiaCadastro.class);
                startActivity(intent);
                finish();
            }
        });
    }


    class CustomAdapter extends BaseAdapter {

        @Override
        public int getCount() { return Titulo.size(); }

        @Override
        public Object getItem(int position) { return position; }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(final int position, View view, ViewGroup parent) {
            view = getLayoutInflater().inflate(R.layout.list_noticias, null);
            TextView txtTitulo = view.findViewById(R.id.TxtTituloList);
            TextView txtDescricao = view.findViewById(R.id.TxtDescricaoList);
            ImageView imgNoticia = view.findViewById(R.id.imgList);

            Picasso.with(getApplicationContext()).load(Imagem.get(position)).into(imgNoticia);
            txtTitulo.setText(Titulo.get(position));
            txtDescricao.setText(Descricao.get(position));
            return view;
        }
    }
}
