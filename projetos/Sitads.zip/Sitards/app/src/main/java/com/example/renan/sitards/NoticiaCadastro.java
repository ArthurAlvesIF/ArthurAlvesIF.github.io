package com.example.renan.sitards;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class NoticiaCadastro extends AppCompatActivity {

    @Override
    public void finish() {
        super.finish();
        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noticia_cadastro);
        Button btnCadastro= findViewById(R.id.btnCadastro);
        final EditText edtTitulo= findViewById(R.id.edtTitulo);
        final EditText edtDescricao= findViewById(R.id.edtDescricao);
        final EditText edtImgLink = findViewById(R.id.edtImgLink);

        btnCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity mainActivity= new MainActivity();
                mainActivity.Titulo.add(edtTitulo.getText().toString());
                mainActivity.Descricao.add(edtDescricao.getText().toString());
                mainActivity.Imagem.add(edtImgLink.getText().toString());
                finish();
            }
        });
    }
}
