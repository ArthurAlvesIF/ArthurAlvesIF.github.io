package com.example.renan.sitards;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class NoticiaExpand extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noticia_expand);

        TextView txtTitulo = findViewById(R.id.TxtTitulo);
        TextView txtDescricao = findViewById(R.id.TxtDescricao);
        ImageView imgNoticia = findViewById(R.id.imgNoticia);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        txtTitulo.setText(bundle.getString("Titulo"));
        txtDescricao.setText(bundle.getString("Descricao"));
        Picasso.with(getApplicationContext()).load(bundle.getString("foto")).into(imgNoticia);
    }
}
